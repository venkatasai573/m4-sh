package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginBeanPageFactory {
WebDriver driver;
@FindBy(how=How.NAME,using="uName")
@CacheLookup
WebElement userName;

@FindBy(how=How.NAME,using="pwd")
@CacheLookup
WebElement password;

@FindBy(how=How.CLASS_NAME, using="btn btn-primary btn-block")
@CacheLookup
WebElement submitButton;

public LoginBeanPageFactory(WebDriver driver) {
	this.driver = driver;
	PageFactory.initElements(driver, this);
}

public WebElement getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName.sendKeys(userName);
}

public WebElement getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password.sendKeys(password);
}
public WebElement getSubmitButton() {
	return submitButton;
}

public void setSubmitButton() {
	this.submitButton.click();
}

}
